from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from courses.models import Course, Enrollment
from evaluations.models import Submission, Evaluation

User = get_user_model()

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        try:
            user = User.objects.get(email=email)
            if user.check_password(password):
                login(request, user)
                if user.role == 'student':
                    return redirect('accounts:student_dashboard')
                else:
                    return redirect('accounts:teacher_dashboard')
            else:
                messages.error(request, 'Invalid email or password')
        except User.DoesNotExist:
            messages.error(request, 'Invalid email or password')
    
    return render(request, 'accounts/login.html')

def logout_view(request):
    logout(request)
    return redirect('home')

def register_choice_view(request):
    return render(request, 'accounts/register_choice.html')

def student_register_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        roll_number = request.POST.get('roll_number')
        password = request.POST.get('password')
        
        if len(password) != 6:
            messages.error(request, 'Password must be exactly 6 characters')
            return render(request, 'accounts/student_register.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered')
            return render(request, 'accounts/student_register.html')
        
        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
            first_name=name,
            role='student',
            roll_number=roll_number
        )
        
        login(request, user)
        messages.success(request, 'Registration successful!')
        return redirect('accounts:student_dashboard')
    
    return render(request, 'accounts/student_register.html')

def teacher_register_view(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        department = request.POST.get('department')
        password = request.POST.get('password')
        
        if len(password) != 6:
            messages.error(request, 'Password must be exactly 6 characters')
            return render(request, 'accounts/teacher_register.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered')
            return render(request, 'accounts/teacher_register.html')
        
        user = User.objects.create_user(
            username=email,
            email=email,
            password=password,
            first_name=name,
            role='teacher',
            department=department
        )
        
        login(request, user)
        messages.success(request, 'Registration successful!')
        return redirect('accounts:teacher_dashboard')
    
    return render(request, 'accounts/teacher_register.html')

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('accounts:teacher_dashboard')
    
    enrolled_courses = Course.objects.filter(enrollments__student=request.user)
    
    # Get submissions and evaluations for this student
    submissions = Submission.objects.filter(student=request.user)
    evaluations = []
    
    for submission in submissions:
        submission_evaluations = Evaluation.objects.filter(submission=submission)
        evaluations.append({
            'submission': submission,
            'evaluations': submission_evaluations,
            'total_evaluators': submission_evaluations.count(),
        })
    
    context = {
        'enrolled_courses': enrolled_courses,
        'evaluations': evaluations,
    }
    
    return render(request, 'accounts/student_dashboard.html', context)

@login_required
def teacher_dashboard(request):
    if request.user.role != 'teacher':
        return redirect('accounts:student_dashboard')
    
    courses = Course.objects.filter(teacher=request.user)
    
    # Get evaluation statistics
    total_submissions = Submission.objects.filter(assignment__course__teacher=request.user).count()
    evaluated_submissions = Evaluation.objects.filter(teacher=request.user).count()
    pending_evaluations = total_submissions - evaluated_submissions
    
    context = {
        'courses': courses,
        'total_submissions': total_submissions,
        'evaluated_submissions': evaluated_submissions,
        'pending_evaluations': pending_evaluations,
    }
    
    return render(request, 'accounts/teacher_dashboard.html', context)