import { 
  User, UserInsert, 
  Course, CourseInsert, 
  Enrollment, EnrollmentInsert,
  Assignment, AssignmentInsert,
  Submission, SubmissionInsert,
  Evaluation, EvaluationInsert
} from '@shared/schema';

export interface IStorage {
  // User operations
  createUser(user: UserInsert): Promise<User>;
  getUserByEmail(email: string): Promise<User | null>;
  getUserById(id: string): Promise<User | null>;
  
  // Course operations
  createCourse(course: CourseInsert): Promise<Course>;
  getCourseById(id: string): Promise<Course | null>;
  getCourseByCode(courseCode: string): Promise<Course | null>;
  getCoursesByTeacher(teacherId: string): Promise<Course[]>;
  getEnrolledCourses(studentId: string): Promise<Course[]>;
  
  // Enrollment operations
  enrollStudent(enrollment: EnrollmentInsert): Promise<Enrollment>;
  getEnrollmentsByCourse(courseId: string): Promise<Enrollment[]>;
  removeStudentFromCourse(studentId: string, courseId: string): Promise<void>;
  isStudentEnrolled(studentId: string, courseId: string): Promise<boolean>;
  
  // Assignment operations
  createAssignment(assignment: AssignmentInsert): Promise<Assignment>;
  getAssignmentsByCourse(courseId: string): Promise<Assignment[]>;
  getAssignmentById(id: string): Promise<Assignment | null>;
  
  // Submission operations
  createSubmission(submission: SubmissionInsert): Promise<Submission>;
  getSubmissionsByAssignment(assignmentId: string): Promise<Submission[]>;
  getSubmissionByStudentAndAssignment(studentId: string, assignmentId: string): Promise<Submission | null>;
  
  // Evaluation operations
  createEvaluation(evaluation: EvaluationInsert): Promise<Evaluation>;
  getEvaluationsBySubmission(submissionId: string): Promise<Evaluation[]>;
  getEvaluationsByTeacher(teacherId: string): Promise<Evaluation[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private courses: Map<string, Course> = new Map();
  private enrollments: Map<string, Enrollment> = new Map();
  private assignments: Map<string, Assignment> = new Map();
  private submissions: Map<string, Submission> = new Map();
  private evaluations: Map<string, Evaluation> = new Map();

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  // User operations
  async createUser(user: UserInsert): Promise<User> {
    const newUser: User = {
      ...user,
      id: this.generateId(),
      createdAt: new Date(),
    };
    this.users.set(newUser.id, newUser);
    return newUser;
  }

  async getUserByEmail(email: string): Promise<User | null> {
    for (const user of this.users.values()) {
      if (user.email === email) {
        return user;
      }
    }
    return null;
  }

  async getUserById(id: string): Promise<User | null> {
    return this.users.get(id) || null;
  }

  // Course operations
  async createCourse(course: CourseInsert): Promise<Course> {
    const newCourse: Course = {
      ...course,
      id: this.generateId(),
      createdAt: new Date(),
    };
    this.courses.set(newCourse.id, newCourse);
    return newCourse;
  }

  async getCourseById(id: string): Promise<Course | null> {
    return this.courses.get(id) || null;
  }

  async getCourseByCode(courseCode: string): Promise<Course | null> {
    for (const course of this.courses.values()) {
      if (course.courseCode === courseCode) {
        return course;
      }
    }
    return null;
  }

  async getCoursesByTeacher(teacherId: string): Promise<Course[]> {
    return Array.from(this.courses.values()).filter(course => course.teacherId === teacherId);
  }

  async getEnrolledCourses(studentId: string): Promise<Course[]> {
    const studentEnrollments = Array.from(this.enrollments.values())
      .filter(enrollment => enrollment.studentId === studentId);
    
    const courses: Course[] = [];
    for (const enrollment of studentEnrollments) {
      const course = await this.getCourseById(enrollment.courseId);
      if (course) {
        courses.push(course);
      }
    }
    return courses;
  }

  // Enrollment operations
  async enrollStudent(enrollment: EnrollmentInsert): Promise<Enrollment> {
    const newEnrollment: Enrollment = {
      ...enrollment,
      id: this.generateId(),
      enrolledAt: new Date(),
    };
    this.enrollments.set(newEnrollment.id, newEnrollment);
    return newEnrollment;
  }

  async getEnrollmentsByCourse(courseId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(enrollment => enrollment.courseId === courseId);
  }

  async removeStudentFromCourse(studentId: string, courseId: string): Promise<void> {
    for (const [id, enrollment] of this.enrollments.entries()) {
      if (enrollment.studentId === studentId && enrollment.courseId === courseId) {
        this.enrollments.delete(id);
        break;
      }
    }
  }

  async isStudentEnrolled(studentId: string, courseId: string): Promise<boolean> {
    for (const enrollment of this.enrollments.values()) {
      if (enrollment.studentId === studentId && enrollment.courseId === courseId) {
        return true;
      }
    }
    return false;
  }

  // Assignment operations
  async createAssignment(assignment: AssignmentInsert): Promise<Assignment> {
    const newAssignment: Assignment = {
      ...assignment,
      id: this.generateId(),
      createdAt: new Date(),
    };
    this.assignments.set(newAssignment.id, newAssignment);
    return newAssignment;
  }

  async getAssignmentsByCourse(courseId: string): Promise<Assignment[]> {
    return Array.from(this.assignments.values()).filter(assignment => assignment.courseId === courseId);
  }

  async getAssignmentById(id: string): Promise<Assignment | null> {
    return this.assignments.get(id) || null;
  }

  // Submission operations
  async createSubmission(submission: SubmissionInsert): Promise<Submission> {
    const newSubmission: Submission = {
      ...submission,
      id: this.generateId(),
      submittedAt: new Date(),
    };
    this.submissions.set(newSubmission.id, newSubmission);
    return newSubmission;
  }

  async getSubmissionsByAssignment(assignmentId: string): Promise<Submission[]> {
    return Array.from(this.submissions.values()).filter(submission => submission.assignmentId === assignmentId);
  }

  async getSubmissionByStudentAndAssignment(studentId: string, assignmentId: string): Promise<Submission | null> {
    for (const submission of this.submissions.values()) {
      if (submission.studentId === studentId && submission.assignmentId === assignmentId) {
        return submission;
      }
    }
    return null;
  }

  // Evaluation operations
  async createEvaluation(evaluation: EvaluationInsert): Promise<Evaluation> {
    const newEvaluation: Evaluation = {
      ...evaluation,
      id: this.generateId(),
      evaluatedAt: new Date(),
    };
    this.evaluations.set(newEvaluation.id, newEvaluation);
    return newEvaluation;
  }

  async getEvaluationsBySubmission(submissionId: string): Promise<Evaluation[]> {
    return Array.from(this.evaluations.values()).filter(evaluation => evaluation.submissionId === submissionId);
  }

  async getEvaluationsByTeacher(teacherId: string): Promise<Evaluation[]> {
    return Array.from(this.evaluations.values()).filter(evaluation => evaluation.teacherId === teacherId);
  }
}

export const storage = new MemStorage();