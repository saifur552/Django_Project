import { Router } from 'express';
import { storage } from './storage';
import { 
  LoginSchema, 
  StudentRegistrationSchema, 
  TeacherRegistrationSchema,
  CourseInsertSchema,
  CourseEnrollmentSchema,
  AssignmentInsertSchema,
  SubmissionInsertSchema,
  EvaluationInsertSchema
} from '@shared/schema';

const router = Router();

// Authentication routes
router.post('/api/auth/register/student', async (req, res) => {
  try {
    const userData = StudentRegistrationSchema.parse(req.body);
    
    // Check if user already exists
    const existingUser = await storage.getUserByEmail(userData.email);
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    
    const user = await storage.createUser(userData);
    res.json({ user: { ...user, password: undefined } });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Registration failed' });
  }
});

router.post('/api/auth/register/teacher', async (req, res) => {
  try {
    const userData = TeacherRegistrationSchema.parse(req.body);
    
    // Check if user already exists
    const existingUser = await storage.getUserByEmail(userData.email);
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    
    const user = await storage.createUser(userData);
    res.json({ user: { ...user, password: undefined } });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Registration failed' });
  }
});

router.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = LoginSchema.parse(req.body);
    
    const user = await storage.getUserByEmail(email);
    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    res.json({ user: { ...user, password: undefined } });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Login failed' });
  }
});

// Course routes
router.post('/api/courses', async (req, res) => {
  try {
    const courseData = CourseInsertSchema.parse(req.body);
    const course = await storage.createCourse(courseData);
    res.json(course);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Failed to create course' });
  }
});

router.get('/api/courses/teacher/:teacherId', async (req, res) => {
  try {
    const { teacherId } = req.params;
    const courses = await storage.getCoursesByTeacher(teacherId);
    res.json(courses);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch courses' });
  }
});

router.get('/api/courses/student/:studentId', async (req, res) => {
  try {
    const { studentId } = req.params;
    const courses = await storage.getEnrolledCourses(studentId);
    res.json(courses);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch enrolled courses' });
  }
});

router.post('/api/courses/enroll', async (req, res) => {
  try {
    const { courseCode } = CourseEnrollmentSchema.parse(req.body);
    const { studentId } = req.body;
    
    if (!studentId) {
      return res.status(400).json({ error: 'Student ID is required' });
    }
    
    const course = await storage.getCourseByCode(courseCode);
    if (!course) {
      return res.status(404).json({ error: 'Course not found' });
    }
    
    // Check if already enrolled
    const isEnrolled = await storage.isStudentEnrolled(studentId, course.id);
    if (isEnrolled) {
      return res.status(400).json({ error: 'Already enrolled in this course' });
    }
    
    const enrollment = await storage.enrollStudent({
      studentId,
      courseId: course.id
    });
    
    res.json({ enrollment, course });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Failed to enroll' });
  }
});

// Get course enrollments (for teachers)
router.get('/api/courses/:courseId/enrollments', async (req, res) => {
  try {
    const { courseId } = req.params;
    const enrollments = await storage.getEnrollmentsByCourse(courseId);
    
    // Get student details for each enrollment
    const enrollmentsWithStudents = await Promise.all(
      enrollments.map(async (enrollment) => {
        const student = await storage.getUserById(enrollment.studentId);
        return {
          ...enrollment,
          student: student ? { ...student, password: undefined } : null
        };
      })
    );
    
    res.json(enrollmentsWithStudents);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch enrollments' });
  }
});

// Remove student from course
router.delete('/api/courses/:courseId/students/:studentId', async (req, res) => {
  try {
    const { courseId, studentId } = req.params;
    await storage.removeStudentFromCourse(studentId, courseId);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to remove student' });
  }
});

// Assignment routes
router.post('/api/assignments', async (req, res) => {
  try {
    const assignmentData = AssignmentInsertSchema.parse(req.body);
    const assignment = await storage.createAssignment(assignmentData);
    res.json(assignment);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Failed to create assignment' });
  }
});

router.get('/api/courses/:courseId/assignments', async (req, res) => {
  try {
    const { courseId } = req.params;
    const assignments = await storage.getAssignmentsByCourse(courseId);
    res.json(assignments);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch assignments' });
  }
});

// Submission routes
router.post('/api/submissions', async (req, res) => {
  try {
    const submissionData = SubmissionInsertSchema.parse(req.body);
    const submission = await storage.createSubmission(submissionData);
    res.json(submission);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Failed to submit assignment' });
  }
});

router.get('/api/assignments/:assignmentId/submissions', async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const submissions = await storage.getSubmissionsByAssignment(assignmentId);
    
    // Get student details for each submission
    const submissionsWithStudents = await Promise.all(
      submissions.map(async (submission) => {
        const student = await storage.getUserById(submission.studentId);
        const evaluations = await storage.getEvaluationsBySubmission(submission.id);
        
        // Get teacher details for evaluations
        const evaluationsWithTeachers = await Promise.all(
          evaluations.map(async (evaluation) => {
            const teacher = await storage.getUserById(evaluation.teacherId);
            return {
              ...evaluation,
              teacher: teacher ? { ...teacher, password: undefined } : null
            };
          })
        );
        
        return {
          ...submission,
          student: student ? { ...student, password: undefined } : null,
          evaluations: evaluationsWithTeachers
        };
      })
    );
    
    res.json(submissionsWithStudents);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch submissions' });
  }
});

router.get('/api/students/:studentId/assignments/:assignmentId/submission', async (req, res) => {
  try {
    const { studentId, assignmentId } = req.params;
    const submission = await storage.getSubmissionByStudentAndAssignment(studentId, assignmentId);
    
    if (!submission) {
      return res.status(404).json({ error: 'Submission not found' });
    }
    
    // Get evaluations for this submission
    const evaluations = await storage.getEvaluationsBySubmission(submission.id);
    const evaluationsWithTeachers = await Promise.all(
      evaluations.map(async (evaluation) => {
        const teacher = await storage.getUserById(evaluation.teacherId);
        return {
          ...evaluation,
          teacher: teacher ? { ...teacher, password: undefined } : null
        };
      })
    );
    
    res.json({
      ...submission,
      evaluations: evaluationsWithTeachers
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch submission' });
  }
});

// Evaluation routes
router.post('/api/evaluations', async (req, res) => {
  try {
    const evaluationData = EvaluationInsertSchema.parse(req.body);
    const evaluation = await storage.createEvaluation(evaluationData);
    res.json(evaluation);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Failed to create evaluation' });
  }
});

router.get('/api/teachers/:teacherId/evaluations', async (req, res) => {
  try {
    const { teacherId } = req.params;
    const evaluations = await storage.getEvaluationsByTeacher(teacherId);
    res.json(evaluations);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch evaluations' });
  }
});

// Get teacher's evaluation statistics
router.get('/api/teachers/:teacherId/stats', async (req, res) => {
  try {
    const { teacherId } = req.params;
    
    // Get all courses by teacher
    const courses = await storage.getCoursesByTeacher(teacherId);
    
    // Get all assignments for these courses
    let totalAssignments = 0;
    let totalSubmissions = 0;
    let evaluatedSubmissions = 0;
    
    for (const course of courses) {
      const assignments = await storage.getAssignmentsByCourse(course.id);
      totalAssignments += assignments.length;
      
      for (const assignment of assignments) {
        const submissions = await storage.getSubmissionsByAssignment(assignment.id);
        totalSubmissions += submissions.length;
        
        for (const submission of submissions) {
          const evaluations = await storage.getEvaluationsBySubmission(submission.id);
          const teacherEvaluation = evaluations.find(eval => eval.teacherId === teacherId);
          if (teacherEvaluation) {
            evaluatedSubmissions++;
          }
        }
      }
    }
    
    res.json({
      totalCourses: courses.length,
      totalAssignments,
      totalSubmissions,
      evaluatedSubmissions,
      pendingEvaluations: totalSubmissions - evaluatedSubmissions
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

export default router;