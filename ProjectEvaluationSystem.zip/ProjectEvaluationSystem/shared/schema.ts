import { z } from 'zod';

// User types
export const UserRole = z.enum(['student', 'teacher']);
export type UserRole = z.infer<typeof UserRole>;

// User schema
export const UserSchema = z.object({
  id: z.string(),
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Invalid email'),
  password: z.string().length(6, 'Password must be exactly 6 digits'),
  role: UserRole,
  // Student specific fields
  rollNumber: z.string().optional(),
  // Teacher specific fields
  department: z.string().optional(),
  createdAt: z.date(),
});

export type User = z.infer<typeof UserSchema>;

// Course schema
export const CourseSchema = z.object({
  id: z.string(),
  title: z.string().min(1, 'Course title is required'),
  description: z.string().optional(),
  courseCode: z.string().min(1, 'Course code is required'),
  teacherId: z.string(),
  createdAt: z.date(),
});

export type Course = z.infer<typeof CourseSchema>;

// Enrollment schema
export const EnrollmentSchema = z.object({
  id: z.string(),
  studentId: z.string(),
  courseId: z.string(),
  enrolledAt: z.date(),
});

export type Enrollment = z.infer<typeof EnrollmentSchema>;

// Assignment schema
export const AssignmentSchema = z.object({
  id: z.string(),
  title: z.string().min(1, 'Assignment title is required'),
  description: z.string().optional(),
  courseId: z.string(),
  dueDate: z.date().optional(),
  maxMarks: z.number().positive('Max marks must be positive'),
  createdAt: z.date(),
});

export type Assignment = z.infer<typeof AssignmentSchema>;

// Submission schema
export const SubmissionSchema = z.object({
  id: z.string(),
  studentId: z.string(),
  assignmentId: z.string(),
  fileName: z.string(),
  fileContent: z.string(), // Base64 encoded file content
  submittedAt: z.date(),
});

export type Submission = z.infer<typeof SubmissionSchema>;

// Evaluation schema
export const EvaluationSchema = z.object({
  id: z.string(),
  submissionId: z.string(),
  teacherId: z.string(),
  marks: z.number().min(0, 'Marks cannot be negative'),
  feedback: z.string().optional(),
  evaluatedAt: z.date(),
});

export type Evaluation = z.infer<typeof EvaluationSchema>;

// Insert schemas
export const UserInsertSchema = UserSchema.omit({ id: true, createdAt: true });
export type UserInsert = z.infer<typeof UserInsertSchema>;

export const CourseInsertSchema = CourseSchema.omit({ id: true, createdAt: true });
export type CourseInsert = z.infer<typeof CourseInsertSchema>;

export const EnrollmentInsertSchema = EnrollmentSchema.omit({ id: true, enrolledAt: true });
export type EnrollmentInsert = z.infer<typeof EnrollmentInsertSchema>;

export const AssignmentInsertSchema = AssignmentSchema.omit({ id: true, createdAt: true });
export type AssignmentInsert = z.infer<typeof AssignmentInsertSchema>;

export const SubmissionInsertSchema = SubmissionSchema.omit({ id: true, submittedAt: true });
export type SubmissionInsert = z.infer<typeof SubmissionInsertSchema>;

export const EvaluationInsertSchema = EvaluationSchema.omit({ id: true, evaluatedAt: true });
export type EvaluationInsert = z.infer<typeof EvaluationInsertSchema>;

// Login schema
export const LoginSchema = z.object({
  email: z.string().email('Invalid email'),
  password: z.string().min(1, 'Password is required'),
});

export type LoginData = z.infer<typeof LoginSchema>;

// Registration schemas
export const StudentRegistrationSchema = UserInsertSchema.extend({
  role: z.literal('student'),
  rollNumber: z.string().min(1, 'Roll number is required'),
}).omit({ department: true });

export const TeacherRegistrationSchema = UserInsertSchema.extend({
  role: z.literal('teacher'),
  department: z.string().min(1, 'Department is required'),
}).omit({ rollNumber: true });

export type StudentRegistration = z.infer<typeof StudentRegistrationSchema>;
export type TeacherRegistration = z.infer<typeof TeacherRegistrationSchema>;

// Course enrollment schema
export const CourseEnrollmentSchema = z.object({
  courseCode: z.string().min(1, 'Course code is required'),
});

export type CourseEnrollmentData = z.infer<typeof CourseEnrollmentSchema>;