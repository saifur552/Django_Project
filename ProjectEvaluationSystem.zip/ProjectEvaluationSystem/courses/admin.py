from django.contrib import admin
from .models import Course, Enrollment, Assignment

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'course_code', 'teacher', 'created_at')
    list_filter = ('created_at', 'teacher')
    search_fields = ('title', 'course_code', 'teacher__username')
    readonly_fields = ('course_code', 'created_at')

@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('student', 'course', 'enrolled_at')
    list_filter = ('enrolled_at', 'course')
    search_fields = ('student__username', 'course__title')

@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = ('title', 'course', 'max_marks', 'created_at')
    list_filter = ('created_at', 'course')
    search_fields = ('title', 'course__title')