from django.urls import path
from . import views

app_name = 'courses'

urlpatterns = [
    path('create/', views.create_course, name='create_course'),
    path('enroll/', views.enroll_course, name='enroll_course'),
    path('<int:course_id>/', views.course_detail, name='course_detail'),
    path('<int:course_id>/students/', views.course_students, name='course_students'),
    path('<int:course_id>/remove_student/<int:student_id>/', views.remove_student, name='remove_student'),
    path('<int:course_id>/create_assignment/', views.create_assignment, name='create_assignment'),
    path('assignment/<int:assignment_id>/', views.assignment_detail, name='assignment_detail'),
]