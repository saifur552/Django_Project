from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from .models import Course, Enrollment, Assignment
from evaluations.models import Submission

User = get_user_model()

@login_required
def create_course(request):
    if request.user.role != 'teacher':
        messages.error(request, 'Only teachers can create courses')
        return redirect('accounts:student_dashboard')
    
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        
        course = Course.objects.create(
            title=title,
            description=description,
            teacher=request.user
        )
        
        messages.success(request, f'Course created successfully! Course code: {course.course_code}')
        return redirect('accounts:teacher_dashboard')
    
    return render(request, 'courses/create_course.html')

@login_required
def enroll_course(request):
    if request.user.role != 'student':
        messages.error(request, 'Only students can enroll in courses')
        return redirect('accounts:teacher_dashboard')
    
    if request.method == 'POST':
        course_code = request.POST.get('course_code')
        
        try:
            course = Course.objects.get(course_code=course_code)
            
            if Enrollment.objects.filter(student=request.user, course=course).exists():
                messages.error(request, 'You are already enrolled in this course')
            else:
                Enrollment.objects.create(student=request.user, course=course)
                messages.success(request, f'Successfully enrolled in {course.title}')
                
            return redirect('accounts:student_dashboard')
        except Course.DoesNotExist:
            messages.error(request, 'Invalid course code')
    
    return render(request, 'courses/enroll_course.html')

@login_required
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    # Check if user has access to this course
    if request.user.role == 'student':
        if not Enrollment.objects.filter(student=request.user, course=course).exists():
            messages.error(request, 'You are not enrolled in this course')
            return redirect('accounts:student_dashboard')
    elif request.user.role == 'teacher':
        if course.teacher != request.user:
            messages.error(request, 'You do not have access to this course')
            return redirect('accounts:teacher_dashboard')
    
    assignments = Assignment.objects.filter(course=course)
    
    context = {
        'course': course,
        'assignments': assignments,
    }
    
    return render(request, 'courses/course_detail.html', context)

@login_required
def course_students(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    if request.user.role != 'teacher' or course.teacher != request.user:
        messages.error(request, 'You do not have permission to view this')
        return redirect('accounts:teacher_dashboard')
    
    enrollments = Enrollment.objects.filter(course=course)
    
    context = {
        'course': course,
        'enrollments': enrollments,
    }
    
    return render(request, 'courses/course_students.html', context)

@login_required
def remove_student(request, course_id, student_id):
    course = get_object_or_404(Course, id=course_id)
    student = get_object_or_404(User, id=student_id)
    
    if request.user.role != 'teacher' or course.teacher != request.user:
        messages.error(request, 'You do not have permission to do this')
        return redirect('accounts:teacher_dashboard')
    
    enrollment = get_object_or_404(Enrollment, student=student, course=course)
    enrollment.delete()
    
    messages.success(request, f'Successfully removed {student.first_name} from the course')
    return redirect('courses:course_students', course_id=course_id)

@login_required
def create_assignment(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    
    if request.user.role != 'teacher' or course.teacher != request.user:
        messages.error(request, 'You do not have permission to create assignments')
        return redirect('accounts:teacher_dashboard')
    
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        max_marks = request.POST.get('max_marks')
        
        Assignment.objects.create(
            title=title,
            description=description,
            course=course,
            max_marks=int(max_marks) if max_marks else 100
        )
        
        messages.success(request, 'Assignment created successfully!')
        return redirect('courses:course_detail', course_id=course_id)
    
    context = {
        'course': course,
    }
    
    return render(request, 'courses/create_assignment.html', context)

@login_required
def assignment_detail(request, assignment_id):
    assignment = get_object_or_404(Assignment, id=assignment_id)
    
    # Check permissions
    if request.user.role == 'student':
        if not Enrollment.objects.filter(student=request.user, course=assignment.course).exists():
            messages.error(request, 'You are not enrolled in this course')
            return redirect('accounts:student_dashboard')
    elif request.user.role == 'teacher':
        if assignment.course.teacher != request.user:
            messages.error(request, 'You do not have access to this assignment')
            return redirect('accounts:teacher_dashboard')
    
    if request.user.role == 'student':
        # Check if student has submitted
        try:
            submission = Submission.objects.get(student=request.user, assignment=assignment)
        except Submission.DoesNotExist:
            submission = None
    else:
        # For teachers, show all submissions
        submissions = Submission.objects.filter(assignment=assignment)
        submission = None
    
    context = {
        'assignment': assignment,
        'submission': submission,
    }
    
    if request.user.role == 'teacher':
        context['submissions'] = submissions
    
    return render(request, 'courses/assignment_detail.html', context)