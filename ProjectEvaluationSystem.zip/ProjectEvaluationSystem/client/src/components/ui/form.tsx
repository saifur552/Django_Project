import * as React from "react"
import { useFormContext } from "react-hook-form"

const Form = ({ children, ...props }: React.FormHTMLAttributes<HTMLFormElement>) => {
  return <form {...props}>{children}</form>
}

const FormField = ({ 
  name, 
  children 
}: { 
  name: string
  children: (field: any) => React.ReactNode 
}) => {
  const { register, formState: { errors } } = useFormContext()
  const field = register(name)
  const error = errors[name]
  
  return (
    <div className="space-y-2">
      {children({ ...field, error })}
    </div>
  )
}

const FormItem = ({ children, className }: { children: React.ReactNode, className?: string }) => {
  return <div className={`space-y-2 ${className || ''}`}>{children}</div>
}

const FormLabel = React.forwardRef<HTMLLabelElement, React.LabelHTMLAttributes<HTMLLabelElement>>(
  ({ className, ...props }, ref) => (
    <label
      ref={ref}
      className={`text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${className || ''}`}
      {...props}
    />
  )
)
FormLabel.displayName = "FormLabel"

const FormMessage = ({ children, className }: { children?: React.ReactNode, className?: string }) => {
  if (!children) return null
  
  return (
    <p className={`text-sm font-medium text-red-500 ${className || ''}`}>
      {children}
    </p>
  )
}

export { Form, FormField, FormItem, FormLabel, FormMessage }