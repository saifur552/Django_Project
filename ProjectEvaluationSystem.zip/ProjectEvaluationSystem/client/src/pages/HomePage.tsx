import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BookOpen, Users, FileText } from 'lucide-react';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-gray-900">Project Evaluation System</h1>
          <p className="text-gray-600 mt-2">Streamline project submissions and evaluations</p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Our Platform</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A comprehensive system for students to submit projects and teachers to evaluate them efficiently.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <Card className="text-center">
            <CardHeader>
              <BookOpen className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <CardTitle>Course Management</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Teachers can create courses and manage student enrollments with unique course codes.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <FileText className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <CardTitle>Project Submissions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Students can easily upload their project files and track submission status.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <CardTitle>Evaluation System</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Teachers can evaluate submissions with detailed feedback and marks.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="text-center space-y-6">
          <h3 className="text-2xl font-bold text-gray-900">Get Started</h3>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/login">
              <Button size="lg" className="w-full sm:w-auto">
                Login to Your Account
              </Button>
            </Link>
            <Link href="/register">
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Create New Account
              </Button>
            </Link>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t mt-20">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 Project Evaluation System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}