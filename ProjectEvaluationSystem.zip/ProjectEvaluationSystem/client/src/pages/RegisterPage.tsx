import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { StudentRegistrationSchema, TeacherRegistrationSchema, StudentRegistration, TeacherRegistration } from '@shared/schema';
import { useAuth } from '@/hooks/useAuth';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { UserPlus, User, GraduationCap } from 'lucide-react';

export default function RegisterPage() {
  const [, setLocation] = useLocation();
  const { setUser } = useAuth();
  const [error, setError] = useState<string>('');
  const [userType, setUserType] = useState<'student' | 'teacher'>('student');

  const studentForm = useForm<StudentRegistration>({
    resolver: zodResolver(StudentRegistrationSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
      rollNumber: '',
      role: 'student',
    },
  });

  const teacherForm = useForm<TeacherRegistration>({
    resolver: zodResolver(TeacherRegistrationSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
      department: '',
      role: 'teacher',
    },
  });

  const registerMutation = useMutation({
    mutationFn: (data: { userData: StudentRegistration | TeacherRegistration; type: 'student' | 'teacher' }) => 
      apiRequest(`/api/auth/register/${data.type}`, {
        method: 'POST',
        body: JSON.stringify(data.userData),
      }),
    onSuccess: (data) => {
      setUser(data.user);
      setLocation(data.user.role === 'student' ? '/student/dashboard' : '/teacher/dashboard');
    },
    onError: (error: Error) => {
      setError(error.message);
    },
  });

  const onSubmitStudent = (data: StudentRegistration) => {
    setError('');
    registerMutation.mutate({ userData: data, type: 'student' });
  };

  const onSubmitTeacher = (data: TeacherRegistration) => {
    setError('');
    registerMutation.mutate({ userData: data, type: 'teacher' });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full space-y-8 p-8">
        <div className="text-center">
          <UserPlus className="w-12 h-12 text-blue-600 mx-auto" />
          <h2 className="mt-6 text-3xl font-bold text-gray-900">Create your account</h2>
          <p className="mt-2 text-sm text-gray-600">
            Already have an account?{' '}
            <Link href="/login">
              <span className="font-medium text-blue-600 hover:text-blue-500 cursor-pointer">
                Sign in
              </span>
            </Link>
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Register</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4 mb-6">
              <Button
                type="button"
                variant={userType === 'student' ? 'default' : 'outline'}
                onClick={() => setUserType('student')}
                className="flex-1"
              >
                <GraduationCap className="w-4 h-4 mr-2" />
                Student
              </Button>
              <Button
                type="button"
                variant={userType === 'teacher' ? 'default' : 'outline'}
                onClick={() => setUserType('teacher')}
                className="flex-1"
              >
                <User className="w-4 h-4 mr-2" />
                Teacher
              </Button>
            </div>

            {userType === 'student' ? (
              <FormProvider {...studentForm}>
                <Form onSubmit={studentForm.handleSubmit(onSubmitStudent)} className="space-y-4">
                  <FormField name="name">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <Input placeholder="Enter your full name" {...field} />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  <FormField name="email">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <Input type="email" placeholder="Enter your email" {...field} />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  <FormField name="rollNumber">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Roll Number</FormLabel>
                        <Input placeholder="Enter your roll number" {...field} />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  <FormField name="password">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <Input
                          type="password"
                          placeholder="Enter 6-digit password"
                          maxLength={6}
                          {...field}
                        />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  {error && (
                    <div className="text-red-600 text-sm text-center">{error}</div>
                  )}

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? 'Creating Account...' : 'Create Student Account'}
                  </Button>
                </Form>
              </FormProvider>
            ) : (
              <FormProvider {...teacherForm}>
                <Form onSubmit={teacherForm.handleSubmit(onSubmitTeacher)} className="space-y-4">
                  <FormField name="name">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <Input placeholder="Enter your full name" {...field} />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  <FormField name="email">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <Input type="email" placeholder="Enter your email" {...field} />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  <FormField name="department">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Department</FormLabel>
                        <Input placeholder="Enter your department" {...field} />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  <FormField name="password">
                    {({ error, ...field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <Input
                          type="password"
                          placeholder="Enter 6-digit password"
                          maxLength={6}
                          {...field}
                        />
                        <FormMessage>{error?.message}</FormMessage>
                      </FormItem>
                    )}
                  </FormField>

                  {error && (
                    <div className="text-red-600 text-sm text-center">{error}</div>
                  )}

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? 'Creating Account...' : 'Create Teacher Account'}
                  </Button>
                </Form>
              </FormProvider>
            )}
          </CardContent>
        </Card>

        <div className="text-center">
          <Link href="/">
            <span className="text-blue-600 hover:text-blue-500 cursor-pointer">
              Back to home
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}