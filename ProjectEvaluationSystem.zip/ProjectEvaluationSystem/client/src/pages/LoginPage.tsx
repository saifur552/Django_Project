import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { LoginSchema, LoginData } from '@shared/schema';
import { useAuth } from '@/hooks/useAuth';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { LogIn } from 'lucide-react';

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { setUser } = useAuth();
  const [error, setError] = useState<string>('');

  const form = useForm<LoginData>({
    resolver: zodResolver(LoginSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const loginMutation = useMutation({
    mutationFn: (data: LoginData) => apiRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
    onSuccess: (data) => {
      setUser(data.user);
      setLocation(data.user.role === 'student' ? '/student/dashboard' : '/teacher/dashboard');
    },
    onError: (error: Error) => {
      setError(error.message);
    },
  });

  const onSubmit = (data: LoginData) => {
    setError('');
    loginMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full space-y-8 p-8">
        <div className="text-center">
          <LogIn className="w-12 h-12 text-blue-600 mx-auto" />
          <h2 className="mt-6 text-3xl font-bold text-gray-900">Sign in to your account</h2>
          <p className="mt-2 text-sm text-gray-600">
            Or{' '}
            <Link href="/register">
              <span className="font-medium text-blue-600 hover:text-blue-500 cursor-pointer">
                create a new account
              </span>
            </Link>
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Login</CardTitle>
          </CardHeader>
          <CardContent>
            <FormProvider {...form}>
              <Form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField name="email">
                  {({ error, ...field }) => (
                    <FormItem>
                      <FormLabel>Email address</FormLabel>
                      <Input
                        type="email"
                        placeholder="Enter your email"
                        {...field}
                      />
                      <FormMessage>{error?.message}</FormMessage>
                    </FormItem>
                  )}
                </FormField>

                <FormField name="password">
                  {({ error, ...field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <Input
                        type="password"
                        placeholder="Enter your 6-digit password"
                        {...field}
                      />
                      <FormMessage>{error?.message}</FormMessage>
                    </FormItem>
                  )}
                </FormField>

                {error && (
                  <div className="text-red-600 text-sm text-center">{error}</div>
                )}

                <Button
                  type="submit"
                  className="w-full"
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? 'Signing in...' : 'Sign in'}
                </Button>
              </Form>
            </FormProvider>
          </CardContent>
        </Card>

        <div className="text-center">
          <Link href="/">
            <span className="text-blue-600 hover:text-blue-500 cursor-pointer">
              Back to home
            </span>
          </Link>
        </div>
      </div>
    </div>
  );
}