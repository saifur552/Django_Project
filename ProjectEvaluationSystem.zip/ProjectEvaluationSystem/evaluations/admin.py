from django.contrib import admin
from .models import Submission, Evaluation

@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ('student', 'assignment', 'submitted_at')
    list_filter = ('submitted_at', 'assignment__course')
    search_fields = ('student__username', 'assignment__title')

@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = ('submission', 'teacher', 'marks', 'evaluated_at')
    list_filter = ('evaluated_at', 'teacher')
    search_fields = ('submission__student__username', 'teacher__username')