from django.urls import path
from . import views

app_name = 'evaluations'

urlpatterns = [
    path('submit/<int:assignment_id>/', views.submit_assignment, name='submit_assignment'),
    path('evaluate/<int:submission_id>/', views.evaluate_submission, name='evaluate_submission'),
    path('submission/<int:submission_id>/', views.submission_detail, name='submission_detail'),
]