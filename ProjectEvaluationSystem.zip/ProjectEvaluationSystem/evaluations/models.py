from django.db import models
from django.contrib.auth import get_user_model
from courses.models import Assignment

User = get_user_model()

class Submission(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='submissions')
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE, related_name='submissions')
    file = models.FileField(upload_to='submissions/')
    submitted_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('student', 'assignment')
    
    def __str__(self):
        return f"{self.student.username} - {self.assignment.title}"

class Evaluation(models.Model):
    submission = models.ForeignKey(Submission, on_delete=models.CASCADE, related_name='evaluations')
    teacher = models.ForeignKey(User, on_delete=models.CASCADE, related_name='evaluations_given')
    marks = models.IntegerField()
    feedback = models.TextField(blank=True)
    evaluated_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('submission', 'teacher')
    
    def __str__(self):
        return f"{self.submission} - {self.marks} marks by {self.teacher.username}"