from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from courses.models import Assignment, Enrollment
from .models import Submission, Evaluation

User = get_user_model()

@login_required
def submit_assignment(request, assignment_id):
    assignment = get_object_or_404(Assignment, id=assignment_id)
    
    if request.user.role != 'student':
        messages.error(request, 'Only students can submit assignments')
        return redirect('accounts:teacher_dashboard')
    
    # Check if student is enrolled in the course
    if not Enrollment.objects.filter(student=request.user, course=assignment.course).exists():
        messages.error(request, 'You are not enrolled in this course')
        return redirect('accounts:student_dashboard')
    
    # Check if already submitted
    if Submission.objects.filter(student=request.user, assignment=assignment).exists():
        messages.error(request, 'You have already submitted this assignment')
        return redirect('courses:assignment_detail', assignment_id=assignment_id)
    
    if request.method == 'POST':
        file = request.FILES.get('file')
        
        if not file:
            messages.error(request, 'Please select a file to upload')
            return render(request, 'evaluations/submit_assignment.html', {'assignment': assignment})
        
        Submission.objects.create(
            student=request.user,
            assignment=assignment,
            file=file
        )
        
        messages.success(request, 'Assignment submitted successfully!')
        return redirect('courses:assignment_detail', assignment_id=assignment_id)
    
    context = {
        'assignment': assignment,
    }
    
    return render(request, 'evaluations/submit_assignment.html', context)

@login_required
def evaluate_submission(request, submission_id):
    submission = get_object_or_404(Submission, id=submission_id)
    
    if request.user.role != 'teacher':
        messages.error(request, 'Only teachers can evaluate submissions')
        return redirect('accounts:student_dashboard')
    
    # Check if teacher has access to this assignment's course
    if submission.assignment.course.teacher != request.user:
        messages.error(request, 'You do not have permission to evaluate this submission')
        return redirect('accounts:teacher_dashboard')
    
    # Check if already evaluated by this teacher
    if Evaluation.objects.filter(submission=submission, teacher=request.user).exists():
        messages.error(request, 'You have already evaluated this submission')
        return redirect('courses:assignment_detail', assignment_id=submission.assignment.id)
    
    if request.method == 'POST':
        marks = request.POST.get('marks')
        feedback = request.POST.get('feedback')
        
        if not marks:
            messages.error(request, 'Please provide marks')
            return render(request, 'evaluations/evaluate_submission.html', {'submission': submission})
        
        try:
            marks = int(marks)
            if marks < 0 or marks > submission.assignment.max_marks:
                messages.error(request, f'Marks should be between 0 and {submission.assignment.max_marks}')
                return render(request, 'evaluations/evaluate_submission.html', {'submission': submission})
        except ValueError:
            messages.error(request, 'Please enter valid marks')
            return render(request, 'evaluations/evaluate_submission.html', {'submission': submission})
        
        Evaluation.objects.create(
            submission=submission,
            teacher=request.user,
            marks=marks,
            feedback=feedback
        )
        
        messages.success(request, 'Evaluation submitted successfully!')
        return redirect('courses:assignment_detail', assignment_id=submission.assignment.id)
    
    context = {
        'submission': submission,
    }
    
    return render(request, 'evaluations/evaluate_submission.html', context)

@login_required
def submission_detail(request, submission_id):
    submission = get_object_or_404(Submission, id=submission_id)
    
    # Check permissions
    if request.user.role == 'student':
        if submission.student != request.user:
            messages.error(request, 'You can only view your own submissions')
            return redirect('accounts:student_dashboard')
    elif request.user.role == 'teacher':
        if submission.assignment.course.teacher != request.user:
            messages.error(request, 'You do not have access to this submission')
            return redirect('accounts:teacher_dashboard')
    
    evaluations = Evaluation.objects.filter(submission=submission)
    
    context = {
        'submission': submission,
        'evaluations': evaluations,
    }
    
    return render(request, 'evaluations/submission_detail.html', context)